package dartOyunu;

public class Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Player pl1 = new Player();
		pl1.playTheGame();
	}

}
