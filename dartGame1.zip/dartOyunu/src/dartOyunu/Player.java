package dartOyunu; // tek kişilik dart oyunu kodu

import java.util.Random;

public class Player {
	public int sayi;
	public String name;
	public final int numberOfThrows = 10; // max atış miktarı
	public int Score = 0;

	public void Throw() {
		Random rnd = new Random();
		// System.out.println(rnd.nextInt());
		sayi = rnd.nextInt(100) + 1;

		if (sayi <= 50) {
			System.out.println(sayi + "-- miss");
		} else {
			System.out.println(sayi + "-- hit");

			sayi = rnd.nextInt(100) + 1;

			if (sayi <= 50) {
				Score += 5;
				System.out.println("Hit Value " + sayi);
				System.out.println("Score is: " + Score);
			} else if (sayi <= 85 & sayi > 50) {
				Score += 15;
				System.out.println("Hit Value " + sayi);
				System.out.println("Score is: " + Score);
			} else if (sayi <= 100 & sayi > 85) {
				Score += 20;
				System.out.println("Hit Value " + sayi);
				System.out.println("Score is: " + Score);
			}
		}
	}

	public void playTheGame() {
		for (int i = 1; i <= numberOfThrows; i++) {
			System.out.println(i + ". throw");

			Throw();
		}
		System.out.println("TOTAL SCORE is " + Score);
	}
}